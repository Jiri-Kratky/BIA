import math
import random


class Algorithm:
    def __init__():
        pass

    def execute():
        pass


class BlindSearch(Algorithm):
    def __init__(self):
        self.min = 0
        self.max = 0

    def execute(self):
        return random.uniform(self.min, self.max)
